#Initialization 
#First install ggplot2 package
#To install mixOmics you may have to reinstall R and execute this command
#if (!requireNamespace("BiocManager", quietly = TRUE)){
#  install.packages("BiocManager")}
#BiocManager::install("mixOmics")

#If it still not work, try to read the error message and reinstall by hand all the package it need (It's not hard)

################################### PLS-DA ANALYSIS ############################
library(mixOmics)

#Data
titleN1 <- read.table("titlefemaleN1.txt",h = T, stringsAsFactors = T,sep="",dec=",")   #Cqomplete table
data3 <- read.table("FemaleN1.txt",h = T, stringsAsFactors = T,sep="",dec=",") #Row data
dataN3 <- read.table("FemaleN3.txt",h = T, stringsAsFactors = T,sep="",dec=",")
titleN3 <- read.table("titlefemaleN3.txt",h = T, stringsAsFactors = T,sep="",dec=",")
summary(data)
#Variable <- c("Valine",	"Leucine",	"Ac_phosphorique",	"Glycerol",	"Proline",	"Glycine",	"Ac_glycerique",	"Ac_fumarique",	"Serine",	"Ac_malique",	"Methionine",	"Ac_aspartique",	"Ac_aminobutyrique",	"Phenylalanine",	"Citrulline",	"Xylitol",	"Arabitol",	"G3P",	"Ornithine",	"Ac_citrique",	"Glucose1",	"Glucose2",	"Inositol",	"G6P",	"Maltose","Trehalose")
X <- data.matrix(data3) #N1 table
XN3 <- data.matrix(dataN3)
Y <- titleN1[,1] #N3 title
YN3 <- titleN3[,1] #N3 title
#To verify the data
summary(Y) 
dim(XN3)
length(YN3)

################# No selection here, it's a classic PLS-DA #####################
############# N1 ############
MyResult.plsda <- plsda(X,Y)               # 1 Run the method
plotIndiv(MyResult.plsda)                  # 2 Plot the samples
plotVar(MyResult.plsda, cutoff = 0.5)      # 3 Plot the variables

#Surround the groups
plotIndiv(MyResult.plsda, ind.names = FALSE, legend=TRUE,
          ellipse = TRUE, star = F, title = 'Female N1',
          X.label = 'PLS-DA 1', Y.label = 'PLS-DA 2',style = "ggplot2",cex=2)


############# N3 ############
MyResult.plsda <- plsda(XN3,YN3)               # 1 Run the method
plotIndiv(MyResult.plsda)                  # 2 Plot the samples
plotVar(MyResult.plsda, cutoff = 0.5)      # 3 Plot the variables

#Surround the groups
plotIndiv(MyResult.plsda, ind.names = FALSE, legend=TRUE,
          ellipse = TRUE, star = F, title = 'Female N3',
          X.label = 'PLS-DA 1', Y.label = 'PLS-DA 2',style = "ggplot2",cex=2)

vipN3 <- vip(MyResult.plsda)

barplot(vipN3,beside=T,horiz = T)
legend(x="bottomright",legend = rownames(vipN3),fill=rainbow(50),cex=0.5)

#############################Test correlation#################################
library(corrplot)

corel=cor(data3)
corel=cor(dataN3)
corrplot(corel, type="upper", order="hclust", tl.col="black", tl.srt=45, method= "number")

#################################################################################
############################## correlation 90 % #################################
#################################################################################

library(dplyr)
X <- data.matrix(select(data3,-Leucine))
XN3 <- data.matrix(select(dataN3,-c(Leucine,Ac_aspartique)))
Y <- titleN1[,1] #N3 title
YN3 <- titleN3[,1]
dim(XN3)
length(YN3)
############# N1 ############
MyResult.plsda <- plsda(X,Y)               # 1 Run the method
plotIndiv(MyResult.plsda)                  # 2 Plot the samples
plotVar(MyResult.plsda, cutoff = 0.5)      # 3 Plot the variables

#Surround the groups
plotIndiv(MyResult.plsda, ind.names = FALSE, legend=TRUE,
          ellipse = TRUE, star = F, title = 'Female N1 90%',
          X.label = 'PLS-DA 1', Y.label = 'PLS-DA 2',style = "ggplot2",cex=2)


############# N3 ############
MyResult.plsda <- plsda(XN3,YN3)               # 1 Run the method
plotIndiv(MyResult.plsda)                  # 2 Plot the samples
plotVar(MyResult.plsda, cutoff = 0.5)      # 3 Plot the variables

#Surround the groups
plotIndiv(MyResult.plsda, ind.names = FALSE, legend=TRUE,
          ellipse = TRUE, star = F, title = 'Female N3 90%',
          X.label = 'PLS-DA 1', Y.label = 'PLS-DA 2',style = "ggplot2",cex=2)


#################################################################################
############################## correlation 80 % #################################
#################################################################################

library(dplyr)
X <- data.matrix(select(data3,-c(Leucine,Inositol,Ac_aspartique,Ac_fumarique,Ac_aminobutyrique,Ornithine,Methionine,Phenylalanine,Ac_phosphorique)))
XN3 <- data.matrix(select(dataN3,-c(Leucine,Ac_aspartique,Citrulline,Ornithine,Inositol,Ac_fumarique,Maltose)))
Y <- titleN1[,1] #N3 title
YN3 <- titleN3[,1]
dim(XN3)
length(YN3)
############# N1 ############
MyResult.plsda <- plsda(X,Y)               # 1 Run the method
plotIndiv(MyResult.plsda)                  # 2 Plot the samples
plotVar(MyResult.plsda, cutoff = 0.5)      # 3 Plot the variables

#Surround the groups
plotIndiv(MyResult.plsda, ind.names = FALSE, legend=TRUE,
          ellipse = TRUE, star = F, title = 'Female N1 80%',
          X.label = 'PLS-DA 1', Y.label = 'PLS-DA 2',style = "ggplot2",cex=2)


############# N3 ############
MyResult.plsda <- plsda(XN3,YN3)               # 1 Run the method
plotIndiv(MyResult.plsda)                  # 2 Plot the samples
plotVar(MyResult.plsda, cutoff = 0.5)      # 3 Plot the variables

#Surround the groups
plotIndiv(MyResult.plsda, ind.names = FALSE, legend=TRUE,
          ellipse = TRUE, star = F, title = 'Female N3 80%',
          X.label = 'PLS-DA 1', Y.label = 'PLS-DA 2',style = "ggplot2",cex=2)
