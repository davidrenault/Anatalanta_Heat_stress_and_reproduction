#Number of larvae from 2/9/20 to 27/11/20
larv <- read.table("larves_semaines2020.txt",h=T,sep="",dec=",") #I replace empty box by 0
View(larv)
length(larv)
larv_C1 <- larv[1:3,]
larv_C2 <- larv[4:6,]
larv_C3 <- larv[7:9,]

#########  Inapropriate  ##########
kruskal.test(larv_C1[,2:length(larv)])
kruskal.test(larv_C2[,2:length(larv)]) 
kruskal.test(larv_C3[,2:length(larv)]) #Every week is different for every condition so we can't group them

moyVector <- function(x){
  moy = numeric(length(x))
  for (i in 1:length(x)){
    moy[i] = mean(x[,i])
  }
  return(moy)
}

moy_larv_c1 <- moyVector(larv_C1)
moy_larv_c2 <- moyVector(larv_C2)
moy_larv_c3 <- moyVector(larv_C3)

plot(moy_larv_c1,type="l",col="red",ylim=c(0,250),lwd=2,xlab="Time",ylab="Number of larvae")
lines(moy_larv_c2,col="blue",lwd=2)
lines(moy_larv_c3,col="yellow",lwd=2)
legend(x="topright",legend=c("C1","C2","C3"),fill=c("red","blue","yellow"))



#########################################Confidence interval (not the best idea)
################################################################################
intconf <- function(x){
  table=numeric(1000)
  for(i in 1:1000){
    table[i]=mean(sample(x,11,replace=T)) 
  }
  table.sorted=sort(table) 
  return(c(table.sorted[25], table.sorted[975]))
}
int1 = intconf(moy_larv_c1)
int2 = intconf(moy_larv_c2)
int3 = intconf(moy_larv_c3)
library(gplots) # Fonction pour charger gplots qui permet d'ajouter des intervalles de confiance
plotCI(x=c(1:length(larv)), moy_larv_c1, uiw=int1, type="p", pch=16, gap=0.1, add=TRUE, lwd=1.2)
plotCI(x=c(1:length(larv)), moy_larv_c2, uiw=int2, type="p", pch=16, gap=0.1, add=TRUE, lwd=1.2)
plotCI(x=c(1:length(larv)), moy_larv_c3, uiw=int3, type="p", pch=16, gap=0.1, add=TRUE, lwd=1.2)

################################################################################
################################################################################

#Nul : kruskal.test(list(moy_larv_c1,moy_larv_c2,moy_larv_c3,moy_larv_c4)) #There is no difference between all the condition
#We're gonna test every week for every condition
#This function will give us the week where number of larvae are different
kwlarv <- function(C1,C2,C3){
  c=c()
  p=0
  for (i in 1:length(C1)){
    p = kruskal.test(list(C1[,i],C2[,i],C3[,i]))$p.value
    if (is.na(p)){
      c=c(c,NA)
    } else if (p < 0.05){
      c=c(c,i)
    }
  }
  return(c)
}

kwlarv(larv_C1,larv_C2,larv_C3)
kruskal.test(list(larv_C1[,11],larv_C2[,11],larv_C3[,11]))$p.value
#There is no significant difference between the condition


