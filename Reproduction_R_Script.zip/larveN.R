lar <- read.table("larvesN.txt",h = T, sep = "", dec = ".")
tit <- read.table("larvesNtitle.txt",h = T, sep = "", dec = ".")

plot(lar[,1],type="l",col="yellow",ylim=c(0,180),lwd=2,xlab="Time (day)",ylab="Total number of larvae",frame=F,axes=F)
axis(2)
axis(1,at=c(1:13), labels=tit[,1]) 
lines(lar[,2],col="orange",lwd=2)
lines(lar[,3],col="red",lwd=2)
legend(x="topleft",legend=c("N1","N2","N3"),fill=c("yellow","orange","red"))

