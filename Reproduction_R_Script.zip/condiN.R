###################### number of egg for N condition############################
egg <- read.table("oeuf_condi.txt",h = T, sep = "", dec = ".")     #Init
View(egg)
moy_egg_absN1 <- mean(egg[1:23,2])
moy_egg_qlqN1 <- mean(egg[1:23,3])
moy_egg_nbxN1 <- mean(egg[1:23,4])
N1 <- c(moy_egg_absN1,moy_egg_qlqN1,moy_egg_nbxN1)

moy_egg_absN2 <- mean(egg[24:46,2])
moy_egg_qlqN2 <- mean(egg[24:46,3])
moy_egg_nbxN2 <- mean(egg[24:46,4])
N2 <- c(moy_egg_absN2,moy_egg_qlqN2,moy_egg_nbxN2)

moy_egg_absN3 <- mean(egg[47:63,2])
moy_egg_qlqN3 <- mean(egg[47:63,3])
moy_egg_nbxN3 <- mean(egg[47:63,4])
N3 <- c(moy_egg_absN3,moy_egg_qlqN3,moy_egg_nbxN3)

barplot(c(c(N1[1],N2[1],N3[1]),c(N1[2],N2[2],N3[2]),c(N1[3],N2[3],N3[3])),beside = T,col = c("yellow","orange","red")
        ,names = c(" ","Absence"," "," ","Few"," "," ","Many"," "),ylab = "Proportion of eggs")
legend(x="topright",legend=c("N1","N2","N3"),fill = c("yellow","orange","red"))


##########Confidence interval
#Function for confidence interval
intconf <- function(x){
  table=numeric(1000)
  for(i in 1:1000){
    table[i]=mean(sample(x,11,replace=T)) 
  }
  table.sorted=sort(table) 
  return(c(table.sorted[25], table.sorted[975]))
}


a = intconf(egg[1:23,2]) 
b = intconf(egg[1:23,3]) 
c = intconf(egg[1:23,4])

d = intconf(egg[24:46,2])
e = intconf(egg[24:46,3])
f = intconf(egg[24:46,4])

g = intconf(egg[47:63,2])
h = intconf(egg[47:63,3])
i = intconf(egg[47:63,4])

moyennes=c(moy_egg_absN1,moy_egg_absN2,moy_egg_absN3,moy_egg_qlqN1,moy_egg_qlqN2,moy_egg_qlqN3,moy_egg_nbxN1,moy_egg_nbxN2,moy_egg_nbxN3)
intervalles = c(((a[2]-a[1])/2), ((d[2]-d[1])/2) , ((g[2]-g[1])/2), ((b[2]-b[1])/2), ((e[2]-e[1])/2), ((h[2]-h[1])/2), ((c[2]-c[1])/2), ((f[2]-f[1])/2), ((i[2]-i[1])/2))
bp = barplot(c(N1[1],N2[1],N3[1],N1[2],N2[2],N3[2],N1[3],N2[3],N3[3]),beside = T,col = c("yellow","orange","red")
             ,names = c(" ","Absence"," "," ","Few"," "," ","Many"," "),ylab = "Proportion of eggs",ylim=c(0,1))
arrows(bp,moyennes-intervalles,bp, moyennes+intervalles, lwd=1.5, angle=90,length=0.1,code=3) 
legend(x="topright",legend=c("N1","N2","N3"),fill = c("yellow","orange","red"))


